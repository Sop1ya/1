﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ДЗ4
{
    public class PlayerInventory
    {
        private Item[] items;
        private float weightCapacity;
        private float totalWeight = 0;
        public PlayerInventory(float newWeightCapacity)
        {
            items = new Item[5];
            weightCapacity = newWeightCapacity;
        }

        public Item[] GetItems()
        {
            return items;
        }
        public float WeightCapacity
        {
            get
            {
                return weightCapacity;
            }
        }

        public float GetTotalWeight()
        {
           
            return totalWeight;
        }

        public float GetTotalPrice()
        {
            float totalPrice = 0;
            for (int i = 0; i< items.Length; i++)
            {
                if (items[i] != null)
                {
                    totalPrice += items[i].Price;
                }
            }

            return totalPrice;
        }

        public void AddItem(Item item)
        {
            bool k = false;
            for (int i = 0; i < items.Length; i++)
            {

                if (items[i] == null)
                {
                    k = true;
                    if (totalWeight + item.Weight <= weightCapacity)
                    {

                        items[i] = item;
                        totalWeight += item.Weight;
                        Console.WriteLine("Предмет " + item.Name + " был добавлени в инвентарь");
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Вес предмета " + item.Name + " превышает свободный вес инвентаря. Ваши кармашки не могут вместить данный предмет");
                    }
                    break;
                }

            }
            if (k == false)
            {
                Console.WriteLine("Нету места в инвентаре. Предмет не был добавлен");
            }
        }
        
    }
    
}
