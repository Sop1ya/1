﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ДЗ4
{
    public class Player
    {
        private string name;
        public PlayerInventory playerinventory;


        public string Name
        {
            get
            {
                return name;
            }
        }
        public void PickUpItem(Item item)
        {
            playerinventory.AddItem(item);
        }
        public PlayerInventory Inventory
        {
            get
            {
                return playerinventory;
            }
        }

        
        public void ShowInventory()
        {
            Console.WriteLine("Инвентарь игрока " + this.Name);
            bool hasItems = false;

            for (int i = 0; i < playerinventory.GetItems().Length; i++)
            {
                var item = playerinventory.GetItems()[i];
                if (item != null)
                {
                    item.DisplayInfo();
                    hasItems = true;
                }
            }

            if (!hasItems)
            {
                Console.WriteLine("Инвентарь пуст");
            }
        }

        public Player(string name, PlayerInventory playerinventory)
        {
            this.name = name;
            this.playerinventory = playerinventory;
        }

        public float GetInventoryValue()
        {
            return playerinventory.GetTotalPrice();
        }
    }
}
