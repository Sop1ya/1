﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ДЗ4
{
    public class Item
    {
        private int price;      
        private float weight;
        private string name;

        public string Name
        {
            get
            {
                return name;
            }
        }
        public int Price
        {
            get
            {
                return price;
            }
        }
        public float Weight
        {
            get
            {
                return weight;
            }
        }

        public Item(string name, int price, float weight)
        {
            this.price = price;
            this.weight = weight;
            this.name = name;
        }

        public void DisplayInfo()
        {
            Console.WriteLine("Предмет: " + name);
            Console.WriteLine("Цена: " + price);
            Console.WriteLine("Вес: " + weight);
            Console.WriteLine();

        }

    }
}
