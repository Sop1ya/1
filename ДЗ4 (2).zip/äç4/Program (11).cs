﻿using System.Numerics;
using System.Security.Cryptography.X509Certificates;

namespace ДЗ4
{
    internal class Program
    {
        
        //        🟢 Уровень 1 (легко)
        //1. Создайте класс Item с приватными полями: name(string), price(int), weight(float)
        //2. Добавьте конструктор и публичные свойства только для чтения
        //3. Реализуйте метод DisplayInfo(), который выводит в консоль информацию о предмете
        //4. В Main создайте массив из 2 объектов Item с разными значениями и вызовите DisplayInfo() для каждого
        //Программа должна вывести информацию о двух предметах из массива с заданными параметрами

        //        🟡 Уровень 2 (средне)
        //5. Создайте класс PlayerInventory с приватным массивом Item[] items заданного
                //размера(например, 5 элементов) и приватным полем weightCapacity(float)
                //отвечающий за максимальный вес инвентаря
        //6. Добавьте метод AddItem(Item item), который добавляет предмет в первый свободный
                //элемент массива(если есть место), иначе выводит сообщение, что инвентарь полон.
                //После чего проверить что вес добавляемого предмета меньше тем текущий свободный вес,
                //иначе вывести сообщение что инвентарь не может вместить данный предмет
        //7. Добавьте метод GetTotalWeight(), возвращающий сумму веса всех добавленных предметов
        //8. В Main создайте объект PlayerInventory, добавьте несколько предметов в инвентарь и выведите суммарный вес
                //Программа должна показать точную сумму веса добавленных предметов и корректно обработать попытку добавить предмет в полный массив.
        //Важно: для отработки массива можно создать массив большей длины и ограничить его только вместимости по весу

        //        🔴 Уровень 3 (сложнее)
            //9 Создайте класс Player с полями: name(string) и inventory(экземпляр PlayerInventory)
            //10. Добавьте метод PickUpItem(Item item), который добавляет предмет в инвентарь
            //11. Добавьте метод ShowInventory(), который выводит информацию обо всех предметах в инвентаре
            //12. В Main создайте игрока, несколько предметов, добавьте их через PickUpItem() в инвентарь, вызовите ShowInventory()
                //Вывод: программа должна выводить имя игрока и список предметов, находящихся в инвентаре с полными данными
            //13. В классе PlayerInventory реализуйте метод GetTotalPrice(), возвращающий сумму цен всех предметов
            //14. В классе Player добавьте метод GetInventoryValue(), который возвращает стоимость инвентаря
            //15. В Main выведите суммарную стоимость инвентаря игрока
        //Программа должна показывать вес и общую стоимость всех предметов в инвентаре

        static void Main(string[] args)
        {
            Console.WriteLine("Введите название предмета 1");
            string firstItemName = Console.ReadLine();
            Console.WriteLine("Введите цену предмета");
            int.TryParse(Console.ReadLine(), out int firstprice);
            Console.WriteLine("Введите вес предмета");
            float.TryParse(Console.ReadLine(), out float firstweight);

            Item firstItem = new Item(firstItemName, firstprice, firstweight);

            Console.WriteLine("Введите название предмета 2");
            string secondItemName = Console.ReadLine();
            Console.WriteLine("Введите цену предмета");
            int.TryParse(Console.ReadLine(), out int secondprice);
            Console.WriteLine("Введите вес предммета");
            float.TryParse(Console.ReadLine(), out float secondweight);

            Item secondItem = new Item(secondItemName, secondprice, secondweight);

            Console.WriteLine("Введите название предмета 3");
            string thirdItemName = Console.ReadLine();
            Console.WriteLine("Введите цену предмета");
            int.TryParse(Console.ReadLine(), out int thirdprice);
            Console.WriteLine("Введите вес предмета");
            float.TryParse(Console.ReadLine(), out float thirdweight);

            Item thirdItem = new Item(thirdItemName, thirdprice, thirdweight);

            Item[] InventoryMass = new Item[] {firstItem, secondItem, thirdItem};
            Console.WriteLine();
            Console.WriteLine("В инвентаре сейчас:");
            InventoryMass[0].DisplayInfo();
            InventoryMass[1].DisplayInfo();
            InventoryMass[2].DisplayInfo();


            Console.WriteLine();
            Console.WriteLine("Теперь вместимость инвентаря ограничена по весу");
            Console.WriteLine("Введите максимальный вес инвентаря");
            float.TryParse(Console.ReadLine(), out float WeightCapacity);
            PlayerInventory inventory = new PlayerInventory(WeightCapacity);
            inventory.AddItem(firstItem);
            inventory.AddItem(secondItem);
            inventory.AddItem(thirdItem);

            Console.WriteLine("Общий вес инвентаря: " + inventory.GetTotalWeight());

            Console.WriteLine("Давайте создадим персонажа. Введите имя");
            string PlayerName = Console.ReadLine();
            PlayerInventory playerinventory = new PlayerInventory(10000);


            Player player1 = new Player(PlayerName, playerinventory);

            Item book = new Item("Книга", 150, 500);
            Item lamp = new Item("Фонарик", 200, 200);
            Item Axe = new Item("Топор", 1000, 1700);
            Item Key = new Item("Ключ", 0, 150);

            Console.WriteLine();
            player1.PickUpItem(book);
            player1.PickUpItem(lamp);
            player1.PickUpItem(Axe);
            player1.PickUpItem(Key);

            Console.WriteLine();
            player1.ShowInventory();

            Console.WriteLine();
            Console.WriteLine("Общий вес инвентаря игрока " + PlayerName + "= " + player1.Inventory.GetTotalWeight());
           
            Console.WriteLine("Общая стоимость инвентаря игрока " + PlayerName + "= " + player1.GetInventoryValue());

            Console.ReadKey();

        }

       
    }
}
